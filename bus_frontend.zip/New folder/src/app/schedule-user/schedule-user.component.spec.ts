import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleUserComponent } from './schedule-user.component';

describe('ScheduleUserComponent', () => {
  let component: ScheduleUserComponent;
  let fixture: ComponentFixture<ScheduleUserComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ScheduleUserComponent]
    });
    fixture = TestBed.createComponent(ScheduleUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
