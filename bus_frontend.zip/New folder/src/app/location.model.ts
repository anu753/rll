export interface Location {
  id: number;
  terminal: string;
  state: string;
}
