import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../services/admin.service';

@Component({
  selector: 'app-show-all-booking-details',
  templateUrl: './show-all-booking-details.component.html',
  styleUrls: ['./show-all-booking-details.component.css'],
})
export class ShowAllBookingDetailsComponent implements OnInit {
  constructor(private adminService: AdminService, private router: Router) {}
  userId = null;
  bookings  = null;

  ngOnInit(): void {
    this.adminService.getUsers().subscribe(
      (data) => {
        this.bookings = data;
      });
    }
}