import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllBookingDetailsComponent } from './show-all-booking-details.component';

describe('ShowAllBookingDetailsComponent', () => {
  let component: ShowAllBookingDetailsComponent;
  let fixture: ComponentFixture<ShowAllBookingDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ShowAllBookingDetailsComponent]
    });
    fixture = TestBed.createComponent(ShowAllBookingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
