import { Component, OnInit } from '@angular/core';
import { LocationService } from '../location.service';

interface Location {
  id :number;
  terminal: string;
  state: string;
}

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css'],
})
export class LocationComponent implements OnInit {
  locations: Location[] = [];
  searchQuery: string = ''; //added newly
  filteredLocations: Location[] = []; // Add filteredLocations array
  newLocation: Location = { terminal: '', state: '', id: null};
  selectedLocation: Location | null = null;

  constructor(private locationService: LocationService) {}

  ngOnInit() {
    this.fetchLocations();
  }

  fetchLocations() {
    console.log('Fetching locations');
    this.locationService.getLocations().subscribe(
      (data) => {
        this.locations = data;
      },
      (error) => {
        console.error('Error fetching locations:', error);
      }
    );
  }

  addLocation() {
    console.log('Adding location:', this.newLocation);
    if(this.newLocation != null){
      this.locationService.addLocation(this.newLocation).subscribe(
        () => {
          this.fetchLocations();
          // Clear the newLocation object after successful addition
          this.newLocation = { terminal: '', state: '', id: null };
        },
        (error) => {
          console.error('Error adding location:', error);
        }
      );
    }else
    {
      alert("Fields cannot be Empty");
    }
  }
  

  editLocation(location: Location) {
    this.selectedLocation = { ...location };
  }
    
  
  updateLocation() {
    this.locationService.updateLocation(this.selectedLocation!).subscribe(
      () => {
        this.fetchLocations();
        this.selectedLocation = null;
      },
      (error) => {
        console.error('Error updating location:', error);
      }
    );
  }

  cancelEdit() {
    this.selectedLocation = null;
  }

  deleteLocation(location: Location) {
    console.log('Deleting location:', location);
    this.locationService.deleteLocation(location.id).subscribe(
      () => {
        this.fetchLocations();
      },
      (error) => {
        console.error('Error deleting location:', error);
      }
    );
  }


}
