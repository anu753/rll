import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Location } from './location.model';

@Injectable({
  providedIn: 'root',
})
export class LocationService {
  private baseUrl = 'http://localhost:8086/admin/addLocation';
  private url = 'http://localhost:8086/admin/getLocation';
  private link='http://localhost:8086/admin/updateLocation';
  private dellink='http://localhost:8086/admin/deleteLocation';

  constructor(private http: HttpClient) {}

  getLocations(): Observable<Location[]> {
    return this.http.get<Location[]>(this.url);
  }

  addLocation(location: Location): Observable<any> {
    return this.http.post(this.baseUrl, location);
  }

  updateLocation(location: Location): Observable<any> {
    return this.http.put(`${this.link}/${location.id}`, location);
  }

  deleteLocation(id: number): Observable<any> {
    return this.http.delete(`${this.dellink}/${id}`);
  }
}
