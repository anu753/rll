package com.instabus;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LocationModuleTest {

    private WebDriver driver;
    
    

    @BeforeMethod
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless"); // Run in headless mode
        driver = new ChromeDriver(options);
        driver.get("http://localhost:4200/location");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void testAddLocation() {
    	WebElement addterminal = driver.findElement(By.name("newLocation.terminal"));
    	addterminal.sendKeys("Khan bazaaar");
    	WebElement addstate = driver.findElement(By.name("newLocation.state"));
    	addstate.sendKeys("Delhi");
    	WebElement click = driver.findElement(By.className("add-button"));
		click.sendKeys(Keys.ENTER);
    }
    
    @Test
    public void testGetLocations() {
        WebElement terminalCell = driver.findElement(By.id("a"));
        WebElement stateCell = driver.findElement(By.id("b"));

        String terminal = terminalCell.getText();
        String state = stateCell.getText();

    }


    
    @Test
    public void testUpdateLocation() {
        WebElement updateLocationButton = driver.findElement(By.id("edit"));
        updateLocationButton.click();

        WebElement terminalInput = driver.findElement(By.name("selectedLocation.terminal"));
        terminalInput.clear();
        terminalInput.sendKeys("New Terminal");

        WebElement stateInput = driver.findElement(By.name("selectedLocation.state"));
        stateInput.clear();
        stateInput.sendKeys("New State");

        WebElement saveButton = driver.findElement(By.id("save"));
        saveButton.click();
    }


    @Test
    public void testDeleteLocation() {
    	 WebElement deleteLocationButton = driver.findElement(By.id("delete"));
         deleteLocationButton.click();
    }
}