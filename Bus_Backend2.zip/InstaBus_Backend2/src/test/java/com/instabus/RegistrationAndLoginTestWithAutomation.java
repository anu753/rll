package com.instabus;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;
import org.testng.asserts.SoftAssert;
	public class RegistrationAndLoginTestWithAutomation {		
		private WebDriver driver;
		SoftAssert softassert = new SoftAssert();
		
		@BeforeMethod
		public void setUp() {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");
			driver = new ChromeDriver(options);
		}
		
		@Test(priority=1)
		public void register() {
			driver.get("http://localhost:4200/addUser");
			WebElement username = driver.findElement(By.name("username"));
			username.sendKeys("Anupma");
			WebElement email = driver.findElement(By.name("email"));
			email.sendKeys("Anupma@gmail.com");
			WebElement number = driver.findElement(By.name("number"));
			number.sendKeys("9999999999");
			WebElement password = driver.findElement(By.name("password"));
			password.sendKeys("123456789");
			try 
				{ Thread.sleep(200);}
			 catch (InterruptedException e) 
				{ e.printStackTrace(); }
			WebElement confirmpassword = driver.findElement(By.name("Name"));
			confirmpassword.sendKeys("123456789");
			
			WebElement Register = driver.findElement(By.name("confirmPassword"));
			
			assertTrue(Register.isEnabled());
			
			Register.sendKeys(Keys.ENTER);
			System.out.println("Registration Success!!");
			
			try { Thread.sleep(1000);}
		 catch (InterruptedException e) 
			{ e.printStackTrace(); }
			driver.quit();
		}
		@Test(priority=2)
		public void userlogin() {
			driver.get("http://localhost:4200/userLogin");
			WebElement userid = driver.findElement(By.id("userid"));
			userid.sendKeys("1");
			WebElement password = driver.findElement(By.id("password"));
			password.sendKeys("1234567899");
			WebElement Login = driver.findElement(By.id("login"));
			Login.sendKeys(Keys.ENTER);
			System.out.println("User Login Success!!");
			
			try { Thread.sleep(1000);}
		 catch (InterruptedException e) 
			{ e.printStackTrace(); }
			driver.quit();
		}
		@Test(priority=3)
		public void adminlogin() {
			driver.get("http://localhost:4200/adminLogin");
			WebElement userid = driver.findElement(By.id("userid"));
			userid.sendKeys("224");
			WebElement password = driver.findElement(By.id("password"));
			password.sendKeys("12345678");
			WebElement Login = driver.findElement(By.id("login"));
			Login.sendKeys(Keys.ENTER);
			System.out.println("Admin Login Success!!");
			
			try { Thread.sleep(1000);}
		 catch (InterruptedException e) 
			{ e.printStackTrace(); }
			driver.quit();
		}
	}