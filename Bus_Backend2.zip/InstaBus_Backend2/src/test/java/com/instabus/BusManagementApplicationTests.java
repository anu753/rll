package com.instabus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertThrows;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.instabus.dao.BusDetailsDao;
//import com.instabus.service.AdminService;
import com.instabus.entity.BookingDetails;
import com.instabus.entity.BusDetails;
import com.instabus.entity.Passenger;
import com.instabus.serviceImpl.AdminServiceImpl;
import com.instabus.exception.NullBusDetailsException;
import com.instabus.exception.BusDetailsNotFoundException;
import com.instabus.exception.RecordNotFoundException;

@SpringBootTest
public class BusManagementApplicationTests {
	
	
	@Mock
	private BusDetailsDao busRepo;
	
	@InjectMocks
	private AdminServiceImpl busService;
	
	@BeforeMethod
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void testBusDetails() {
		BusDetails bus=new BusDetails("delhi", "mumbai", 25, "16-04-2023", "16-04-2023", "23:00", "17:00", "prasanna", 7899.00);
		assertNotNull(bus);
		assertEquals("16-04-2023",bus.getDepartureDate());
		assertEquals(25,bus.getAvailableSeats());
		assertEquals("prasanna",bus.getBusVendor());
		assertEquals("delhi",bus.getDepartureBusstop());
		assertEquals("23:00",bus.getArrivalTime());
		assertEquals(7899.00,bus.getCost());
	}
	
	@Test
    public void testBookingDetails() {
		BookingDetails booking = new BookingDetails(1, "22-08-2023", "10:00", 100.0, 123, 456);
        assertNotNull(booking);
        assertEquals(1, booking.getBookingId());
        assertEquals("22-08-2023", booking.getBookingDate());
        assertEquals("10:00", booking.getBookingTime());
        assertEquals(100.0, booking.getTotalCost(), 0.01); // Using a delta for double comparison
        assertEquals(123, booking.getBusNumber());
        assertEquals(456, booking.getOwnerId());
    }
	
	@Test
    public void testPassenger() {
		Passenger passenger= new Passenger(1, "John Doe", 30, 15.0);
        assertNotNull(passenger);
        assertEquals(1, passenger.getPassengerId());
        assertEquals("John Doe", passenger.getName());
        assertEquals(30, passenger.getAge());
        assertEquals(15.0, passenger.getLuggage(), 0.01); // Using a delta for double comparison
    }
	
	
	
	@Test
	public void testGetAllBusDetails() {
		//MockitoAnnotations.initMocks(this);
		when(busRepo.findAll()).thenReturn(Stream
				.of(new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022", 
						"23:00", "17:00", "prasanna", 7899.00)).collect(Collectors.toList()));
		assertEquals(1, busService.getAllBusDetails().size());
	}
	
	@Test
	public void testGetBusDetails() {
		//MockitoAnnotations.initMocks(this);
		when(busRepo.findAll()).thenReturn(Stream
				.of(new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022", 
						"23:00", "17:00", "prasanna", 7899.00), new BusDetails("bangalore", "kolkata", 48, "02-12-2020", "03-12-2020", 
								"05:20", "23:05", "prasanna", 12899.00)).collect(Collectors.toList()));
		assertEquals(2, busService.getAllBusDetails().size());
	}
	
	@Test
	public void testAddBusDetails() {
		//MockitoAnnotations.initMocks(this);
		BusDetails busObj = new BusDetails("pune", "delhi", 56, "18-04-2022", "18-04-2022", 
				"05:00", "23:55", "prasanna", 9899.55);
		when(busRepo.save(busObj)).thenReturn(busObj);
		assertEquals(busObj, busService.addBusDetails(busObj));
	}
	
	@Test
	  public void testFindAllBuses() {
	    List<BusDetails> buses = new ArrayList<>();
	    buses.add(new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022",
	    		"23:00", "17:00", "prasanna", 7899.00));
	    buses.add(new BusDetails("bangalore", "kolkata", 48, "02-12-2020", "03-12-2020", 
				"05:20", "23:05", "prasanna", 12899.00));

	    when(busRepo.findAll()).thenReturn(buses);

	    List<BusDetails> retrievedBuses = busService.getAllBusDetails();

	    assertEquals(2, retrievedBuses.size());
	    assertEquals("delhi", retrievedBuses.get(0).getDepartureBusstop());
        assertEquals("bangalore", retrievedBuses.get(1).getDepartureBusstop());
    }
	
	@Test
	  public void testAddBus() {
		BusDetails busToAdd = new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022",
	    		"23:00", "17:00", "prasanna", 7899.00);

	    when(busRepo.save(busToAdd)).thenReturn(busToAdd);

	    BusDetails result = busService.addBusDetails(busToAdd);

	    assertEquals(busToAdd, result);
	  
	}
	
	@Test
	public void testAddBusDetailsWithNullData() {
	    assertThrows(NullBusDetailsException.class, () -> busService.addBusDetails(null));
	}
	
	
	
	@Test
	public void testUpdateBusDetails() {
		int sampleBusNumber=1;
	    BusDetails existingBus = new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022",
	            "23:00", "17:00", "prasanna", 7899.00);
	    existingBus.setBusNumber(sampleBusNumber); // Set a sample bus number for testing
	    when(busRepo.findById(sampleBusNumber)).thenReturn(Optional.of(existingBus));

	    BusDetails updatedBus = new BusDetails("pune", "mumbai", 30, "18-04-2022", "18-04-2022",
	            "06:00", "19:00", "john", 8500.00);
	    updatedBus.setBusNumber(sampleBusNumber);
	    BusDetails result = busService.updateBus(updatedBus);

	    assertEquals("pune", result.getDepartureBusstop());
	    assertEquals(30, result.getAvailableSeats());
	    assertEquals("john", result.getBusVendor());
	    
	    verify(busRepo).findById(sampleBusNumber);
        verify(busRepo).save(updatedBus);
	}
	
	@Test
    public void testUpdateBusDetailsNonExistentBus() {
        int nonExistentBusNumber = 999;
        BusDetails updatedBus = new BusDetails("pune", "mumbai", 30, "18-04-2022", "18-04-2022",
                "06:00", "19:00", "john", 8500.00);
        updatedBus.setBusNumber(nonExistentBusNumber);

        when(busRepo.findById(nonExistentBusNumber)).thenReturn(Optional.empty());

        assertThrows(BusDetailsNotFoundException.class, () -> busService.updateBus(updatedBus));
    }
	
	@Test
	public void testDeleteBusDetails() {
		int sampleBusNumber=1;
	    BusDetails existingBus = new BusDetails("delhi", "mumbai", 25, "16-04-2022", "16-04-2022",
	            "23:00", "17:00", "prasanna", 7899.00);
	    existingBus.setBusNumber(sampleBusNumber);
	    when(busRepo.findById(sampleBusNumber)).thenReturn(Optional.of(existingBus));

	    busService.deleteBus(sampleBusNumber);
	    
	    verify(busRepo).findById(sampleBusNumber);
	    verify(busRepo).deleteById(sampleBusNumber);
	}
	
	@Test
    public void testDeleteNonExistentBusDetails() {
        int nonExistentBusNumber = 999;
        when(busRepo.findById(nonExistentBusNumber)).thenReturn(Optional.empty());

        assertThrows(BusDetailsNotFoundException.class, () -> busService.deleteBus(nonExistentBusNumber));
    }
	
	@Test
    public void testFindAllBusesEmptyList() {
        when(busRepo.findAll()).thenReturn(new ArrayList<>());

        List<BusDetails> retrievedBuses = busService.getAllBusDetails();

        assertEquals(0, retrievedBuses.size());
    }
    
    @Test
    public void testRecordNotFoundException() {
        assertThrows(RecordNotFoundException.class, () -> {
            throw new RecordNotFoundException("Record not found");
        });
    }
    
  @Test
  public void f() {
  }
}