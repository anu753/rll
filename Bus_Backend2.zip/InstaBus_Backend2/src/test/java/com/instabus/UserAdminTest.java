package com.instabus;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;
import static org.testng.AssertJUnit.assertEquals;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.testng.annotations.Test;

import com.instabus.dao.AdminDao;
import com.instabus.dao.UserDao;
import com.instabus.entity.User;
import com.instabus.utils.UserAuth;
import com.instabus.utils.AdminAuth;

@SpringBootTest
public class UserAdminTest {
	
	@MockBean
	private UserDao userDao;
	
	@MockBean
	private AdminDao adminDao;
	  	
	@Test
	public void testAddUser() {
		User user = new User(100,"Arun","12345678",9999999999l,"arun@example.com");
		assertNotNull(user);
		assertTrue(100==user.getUserId());
		assertEquals("Arun",user.getUserName());
		assertEquals("12345678",user.getPassword());
		assertTrue(9999999999l==user.getPhone());
		assertEquals("arun@example.com",user.getEmail());
	}
	
	@Test
	public void testLoginUser() {
		UserAuth user = new UserAuth(101,"12345678");
		assertTrue(101==user.getUserId());
		assertTrue("12345678"==user.getPassword());
	}
	
	@Test
	public void testLoginAdmin() {
		AdminAuth admin = new AdminAuth(1,"12345678");
		assertTrue(1==admin.getAdminId());
		assertTrue("12345678"==admin.getPassword());
	}
}